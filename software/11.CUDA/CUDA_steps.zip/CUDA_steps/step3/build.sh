mkdir -p build

cd build || false

cmake .. && cmake --build .

cp step3 ..